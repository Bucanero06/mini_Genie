genie_add_ons_paths = dict(
    post_analysis_main="/home/ruben/PycharmProjects/Post_Processing_Genie/post_processing_genie_source/post_processing_genie_main.py",
    tsne_main=None
)
